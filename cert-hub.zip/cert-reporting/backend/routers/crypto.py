"""Crypto tools — cert decoder, CSR decoder, format converter."""
import base64
import subprocess
import tempfile
import os
from datetime import datetime, timezone
from fastapi import APIRouter, Form, UploadFile, File
from fastapi.responses import JSONResponse
from cryptography import x509
from cryptography.hazmat.primitives.serialization import Encoding

router = APIRouter(prefix="/api", tags=["crypto"])


@router.post("/cert-decoder/decode/")
async def cert_decode(pem: str = Form("")):
    if not pem.strip():
        return JSONResponse({"error": "No input provided"}, status_code=400)
    try:
        cert = x509.load_pem_x509_certificate(pem.strip().encode())
        remaining = (cert.not_valid_after_utc - datetime.now(timezone.utc)).days
        lifetime = (cert.not_valid_after_utc - cert.not_valid_before_utc).days
        subj_items = [f"`{a.oid._name}` = **{a.value}**" for a in cert.subject]
        iss_items = [f"`{a.oid._name}` = **{a.value}**" for a in cert.issuer]
        sans = []
        try:
            se = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
            for n in se.value.get_values_for_type(x509.DNSName): sans.append(("DNS", str(n)))
            for ip in se.value.get_values_for_type(x509.IPAddress): sans.append(("IP", str(ip)))
            for e in se.value.get_values_for_type(x509.RFC822Name): sans.append(("Email", str(e)))
        except x509.ExtensionNotFound:
            pass
        status = "expired" if remaining < 0 else ("expiring" if remaining < 30 else "valid")
        return {
            "status": status, "remaining": remaining, "lifetime": lifetime,
            "not_before": cert.not_valid_before_utc.strftime("%Y-%m-%d"),
            "not_after": cert.not_valid_after_utc.strftime("%Y-%m-%d"),
            "key_size": getattr(cert.public_key(), "key_size", "—"),
            "subject_items": subj_items, "issuer_items": iss_items,
            "serial_number": f"{cert.serial_number:x}",
            "sig_algo": cert.signature_algorithm_oid._name,
            "sans": sans, "pem": cert.public_bytes(Encoding.PEM).decode(),
        }
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.post("/csr-decoder/decode/")
async def csr_decode(pem: str = Form("")):
    if not pem.strip():
        return JSONResponse({"error": "No input provided"}, status_code=400)
    try:
        csr = _parse_csr(pem.strip())
        pub_key = csr.public_key()
        subj_items = [f"`{a.oid._name}` = **{a.value}**" for a in csr.subject]
        sans = []
        try:
            se = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName)
            for n in se.value.get_values_for_type(x509.DNSName): sans.append(("DNS", str(n)))
            for ip in se.value.get_values_for_type(x509.IPAddress): sans.append(("IP", str(ip)))
            for e in se.value.get_values_for_type(x509.RFC822Name): sans.append(("Email", str(e)))
        except x509.ExtensionNotFound:
            pass
        return {
            "signature_valid": csr.is_signature_valid,
            "key_size": getattr(pub_key, "key_size", "—"),
            "key_type": pub_key.__class__.__name__.replace("PublicKey", ""),
            "sig_algo": csr.signature_algorithm_oid._name,
            "subject_items": subj_items, "sans": sans,
        }
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


def _parse_csr(pem_data: str):
    pem_bytes = pem_data.strip().encode()
    try:
        return x509.load_pem_x509_csr(pem_bytes)
    except Exception:
        pass
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write(pem_data.strip())
            tmp_in = f.name
        tmp_out = tmp_in + ".out"
        subprocess.run(
            ["openssl", "req", "-in", tmp_in, "-out", tmp_out, "-inform", "PEM", "-outform", "PEM"],
            capture_output=True, text=True, timeout=10,
        )
        with open(tmp_out, "rb") as f:
            csr = x509.load_pem_x509_csr(f.read())
        os.unlink(tmp_in)
        os.unlink(tmp_out)
        return csr
    except Exception:
        pass
    return x509.load_pem_x509_csr(pem_bytes)


@router.post("/format-converter/convert/")
async def format_convert(
    direction: str = Form("pem2der"),
    obj_type: str = Form("cert"),
    pem: str = Form(""),
    b64: str = Form(""),
    der_file: UploadFile = File(None),
):
    try:
        if direction == "pem2der":
            if not pem.strip():
                return JSONResponse({"error": "No input provided"}, status_code=400)
            obj = (
                x509.load_pem_x509_certificate(pem.encode())
                if obj_type == "cert" else x509.load_pem_x509_csr(pem.encode())
            )
            der_bytes = obj.public_bytes(Encoding.DER)
            return {
                "success": True, "direction": "pem2der",
                "size": len(der_bytes), "b64_output": base64.b64encode(der_bytes).decode(),
            }
        else:
            der_bytes = None
            if der_file:
                der_bytes = await der_file.read()
            elif b64.strip():
                try:
                    der_bytes = base64.b64decode(b64.strip())
                except Exception:
                    return JSONResponse({"error": "Invalid Base64 input"}, status_code=400)
            if not der_bytes:
                return JSONResponse({"error": "No input provided"}, status_code=400)
            obj = (
                x509.load_der_x509_certificate(der_bytes)
                if obj_type == "cert" else x509.load_der_x509_csr(der_bytes)
            )
            return {
                "success": True, "direction": "der2pem",
                "pem_output": obj.public_bytes(Encoding.PEM).decode(),
            }
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
