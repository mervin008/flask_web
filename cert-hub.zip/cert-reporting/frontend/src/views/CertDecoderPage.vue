<template>
  <div class="max-w-4xl mx-auto px-4 sm:px-6 py-8">
    <h1 class="text-3xl font-extrabold mb-1">Certificate Decoder</h1><p class="text-base-content/50 mb-6">Paste a PEM-encoded X.509 certificate to inspect its contents.</p>
    <textarea v-model="pem" rows="10" placeholder="-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----" class="textarea textarea-bordered w-full font-mono text-sm"></textarea>
    <div class="flex gap-3 mt-4"><button class="btn btn-primary" @click="decode" :disabled="loading"><span v-if="loading" class="loading loading-spinner loading-sm"></span>Decode</button><button class="btn btn-outline" @click="clear">Clear</button></div>
    <div v-if="error" class="alert alert-error mt-6">{{ error }}</div>
    <div v-if="result" class="mt-8 space-y-4">
      <div :class="['alert',result.status==='valid'?'alert-success':result.status==='expiring'?'alert-warning':'alert-error']">{{ result.status==='valid'?'Valid · '+result.remaining+'d remaining':result.status==='expiring'?'Expiring soon · '+result.remaining+'d remaining':'Expired · '+Math.abs(result.remaining)+'d ago' }}</div>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3"><div v-for="m in metrics" :key="m.label" class="stat bg-base-100 border border-base-300 rounded-box p-4"><div class="stat-title text-xs">{{ m.label }}</div><div class="stat-value text-lg">{{ m.value }}</div></div></div>
      <div v-if="result.subject_items" class="card bg-base-100 border border-base-300"><div class="card-body"><h3 class="text-xs font-semibold uppercase text-base-content/40 mb-2">Subject</h3><p class="text-sm" v-html="result.subject_items.join(' · ')"></p></div></div>
      <div v-if="result.issuer_items" class="card bg-base-100 border border-base-300"><div class="card-body"><h3 class="text-xs font-semibold uppercase text-base-content/40 mb-2">Issuer</h3><p class="text-sm" v-html="result.issuer_items.join(' · ')"></p></div></div>
      <div v-if="result.sans?.length" class="card bg-base-100 border border-base-300"><div class="card-body"><h3 class="text-xs font-semibold uppercase text-base-content/40 mb-2">SANs · {{ result.sans.length }}</h3><div class="flex flex-wrap gap-2"><span v-for="(s,i) in result.sans" :key="i" class="badge badge-outline font-mono text-xs">{{ s[0] }}: {{ s[1] }}</span></div></div></div>
    </div>
  </div>
</template>
<script setup>
import { ref, computed } from 'vue'; import { decodeCert } from '../api'
const pem=ref(''),loading=ref(false),error=ref(null),result=ref(null)
const metrics=computed(()=>result.value?[{label:'Not Before',value:result.value.not_before},{label:'Not After',value:result.value.not_after},{label:'Lifetime',value:result.value.lifetime+'d'},{label:'Key Size',value:result.value.key_size+' bits'}]:[])
async function decode(){if(!pem.value.trim())return;loading.value=true;error.value=null;try{result.value=await decodeCert(pem.value)}catch(e){error.value=e.response?.data?.error||'Decode failed'}finally{loading.value=false}}
function clear(){pem.value='';result.value=null;error.value=null}
</script>
