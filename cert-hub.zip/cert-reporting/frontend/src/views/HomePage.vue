<template>
  <div class="overflow-hidden">
    <!-- Hero -->
    <section class="relative max-w-7xl mx-auto px-4 sm:px-8 pt-16 sm:pt-24 pb-12">
      <div class="absolute inset-0 overflow-hidden pointer-events-none">
        <div class="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary/5 blur-3xl"></div>
        <div class="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-secondary/5 blur-3xl"></div>
        <div class="absolute top-1/3 left-1/2 w-48 h-48 rounded-full bg-accent/5 blur-3xl"></div>
      </div>
      <div class="relative flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-16">
        <div class="w-full lg:w-[55%] space-y-6">
          <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/5 border border-primary/10 text-primary text-xs font-semibold tracking-wide">
            <span class="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
            Google Cloud Certificate Authority Service
          </div>
          <h1 class="text-4xl sm:text-5xl lg:text-[3.5rem] font-black leading-[1.1] tracking-tight">
            Certificate Management<br/>
            <span class="text-primary">Reimagined</span>
          </h1>
          <p class="text-lg text-base-content/50 max-w-xl leading-relaxed">
            Enterprise-grade TLS certificate management for Google Cloud.
            Search, monitor, decode, and convert certificates across your entire infrastructure — all from one powerful dashboard.
          </p>
          <div class="flex flex-wrap gap-3 pt-3">
            <router-link to="/inventory" class="btn btn-primary btn-lg gap-2 shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300 hover:-translate-y-0.5">
              Get Started
              <svg class="size-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
            </router-link>
            <router-link to="/cert-decoder" class="btn btn-outline btn-lg gap-2">
              <svg class="size-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
              Decode a Cert
            </router-link>
          </div>
        </div>
        <div class="w-full lg:w-[45%] relative flex items-center justify-center">
          <div class="relative w-80 h-80 sm:w-96 sm:h-96">
            <div class="absolute inset-0 rounded-3xl bg-gradient-to-br from-primary/10 via-transparent to-secondary/10 animate-float"></div>
            <div class="absolute inset-4 rounded-2xl bg-base-100 border border-base-300/50 shadow-2xl overflow-hidden">
              <div class="h-10 bg-base-200 border-b border-base-300/50 flex items-center px-4 gap-2">
                <div class="w-2.5 h-2.5 rounded-full bg-error/70"></div>
                <div class="w-2.5 h-2.5 rounded-full bg-warning/70"></div>
                <div class="w-2.5 h-2.5 rounded-full bg-success/70"></div>
                <span class="text-[10px] text-base-content/30 ml-2 font-medium">Certificate Hub · Dashboard</span>
              </div>
              <div class="p-5 space-y-3">
                <div class="flex gap-2"><div class="h-3 w-20 rounded bg-primary/20"></div><div class="h-3 w-12 rounded bg-base-200"></div></div>
                <div class="grid grid-cols-3 gap-2"><div v-for="i in 3" :key="i" class="h-16 rounded-lg bg-base-200 p-2"><div class="h-2 w-10 rounded bg-primary/10 mb-1"></div><div class="h-4 w-14 rounded bg-primary/20"></div></div></div>
                <div class="h-32 rounded-lg bg-base-200 p-2"><div class="h-2 w-16 rounded bg-base-300/50 mb-2"></div><div v-for="i in 4" :key="i" class="h-3 rounded bg-base-300/30 mb-1.5" :class="'w-'+(80-i*10)+'%'.replace('80%','11/12').replace('70%','10/12').replace('60%','9/12').replace('50%','8/12')"></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Tools -->
    <section class="max-w-7xl mx-auto px-4 sm:px-8 py-20">
      <div class="text-center mb-12 space-y-3">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/5 border border-primary/10 text-primary text-xs font-semibold">✦ Platform</div>
        <h2 class="text-3xl sm:text-4xl font-black tracking-tight">Enterprise Tools</h2>
        <p class="text-base-content/40 max-w-lg mx-auto">Everything you need to manage certificates at scale. Built for security engineers, by security engineers.</p>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <router-link v-for="t in tools" :key="t.path" :to="t.path"
          class="group card bg-base-100 border border-base-300 hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500 no-underline hover:-translate-y-1">
          <div class="card-body p-6 sm:p-8">
            <div class="flex items-start gap-5">
              <div class="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-110 transition-transform duration-300" :class="t.bg">
                <svg class="size-7" :class="t.color" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" :d="t.icon"/></svg>
              </div>
              <div class="space-y-2">
                <div class="flex items-center gap-2">
                  <h3 class="card-title text-lg">{{ t.title }}</h3>
                  <span v-if="t.badge" class="badge badge-xs" :class="t.badgeClass">{{ t.badge }}</span>
                </div>
                <p class="text-base-content/50 text-sm leading-relaxed">{{ t.desc }}</p>
                <span class="inline-flex items-center gap-1 text-sm font-semibold text-primary opacity-0 group-hover:opacity-100 translate-x-0 group-hover:translate-x-1 transition-all duration-300">
                  Explore <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </span>
              </div>
            </div>
          </div>
        </router-link>
      </div>
    </section>

  </div>
</template>

<script setup>
const tools = [
  { path:'/inventory', title:'Certificate Inventory', badge:'Popular', badgeClass:'badge-primary', desc:'Search and manage all certificates across CA pools. Real-time expiry tracking, multi-dimensional filtering, and bulk export. Monitor your entire PKI infrastructure from one dashboard.', bg:'bg-primary/10', color:'text-primary', icon:'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
  { path:'/csr-decoder', title:'CSR Decoder', badge:'', badgeClass:'', desc:'Deep-inspect Certificate Signing Requests. Verify cryptographic signatures, decode subject fields, validate SANs and extensions, and ensure compliance before submission.', bg:'bg-warning/10', color:'text-warning', icon:'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
  { path:'/cert-decoder', title:'Cert Decoder', badge:'', badgeClass:'', desc:'Parse and analyze X.509 certificates instantly. Extract subject, issuer, validity windows, SANs, key metadata, and all extensions with one-click PEM decoding.', bg:'bg-success/10', color:'text-success', icon:'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z' },
  { path:'/format-converter', title:'Format Converter', badge:'', badgeClass:'', desc:'Seamlessly convert between PEM and DER formats. Upload files or paste Base64 — supports certificates and CSRs. Fast, reliable, and privacy-first processing.', bg:'bg-secondary/10', color:'text-secondary', icon:'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4' },
]
</script>

<style scoped>
@keyframes float { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-8px) } }
@keyframes gradient { 0% { background-position: 0% center } 50% { background-position: 100% center } 100% { background-position: 0% center } }
.animate-float { animation: float 6s ease-in-out infinite }
.animate-gradient { animation: gradient 4s ease infinite }
</style>
