<template>
  <div v-if="store.data" class="mt-6 pt-6 border-t border-base-300 space-y-5">
    <!-- Header -->
    <div class="text-center space-y-3">
      <h2 class="text-lg font-bold">Analytics</h2>
      <!-- Tab pills — centered, prominent -->
      <div class="flex justify-center gap-1">
        <button v-for="(t,i) in tabs" :key="i" @click="activeTab=i"
          :class="['btn btn-sm gap-1.5 transition-all duration-150 min-w-[100px]',
                   activeTab===i ? 'btn-primary shadow-md' : 'btn-ghost border border-base-300']">
          <svg v-if="i===0" class="size-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
          <svg v-else-if="i===1" class="size-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
          <svg v-else class="size-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.618 5.984A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016zM12 9v2m0 4h.01"/></svg>
          {{ t }}
        </button>
      </div>
    </div>

    <!-- Health Monitor -->
    <div v-if="activeTab===0" class="space-y-4">
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><div class="flex items-center justify-between mb-2"><span class="text-[11px] font-semibold uppercase tracking-wider text-base-content/40">24h</span><span class="badge badge-error badge-xs font-bold">{{ store.data.n24 }}</span></div><progress class="progress progress-error h-1.5" :value="store.data.pct_24h" max="100"></progress></div></div>
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><div class="flex items-center justify-between mb-2"><span class="text-[11px] font-semibold uppercase tracking-wider text-base-content/40">7 days</span><span class="badge badge-warning badge-xs font-bold">{{ store.data.n7 }}</span></div><progress class="progress progress-warning h-1.5" :value="store.data.pct_7d" max="100"></progress></div></div>
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><div class="flex items-center justify-between mb-2"><span class="text-[11px] font-semibold uppercase tracking-wider text-base-content/40">30 days</span><span class="badge badge-primary badge-xs font-bold">{{ store.data.n30 }}</span></div><progress class="progress progress-primary h-1.5" :value="store.data.pct_30d" max="100"></progress></div></div>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><h3 class="card-title text-sm">Expiry Radar</h3><div style="height:260px"><canvas ref="rC"></canvas></div></div></div>
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><h3 class="card-title text-sm">Inventory Health</h3><div style="height:260px"><canvas ref="dC"></canvas></div></div></div>
      </div>
    </div>

    <!-- Distribution -->
    <div v-if="activeTab===1" class="space-y-4">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><h3 class="card-title text-sm">By Resource Type</h3><div style="height:320px"><canvas ref="byTypeC"></canvas></div></div></div>
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><h3 class="card-title text-sm">By Location</h3><div style="height:320px"><canvas ref="byLocC"></canvas></div></div></div>
      </div>
    </div>

    <!-- Risk -->
    <div v-if="activeTab===2" class="space-y-4">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><h3 class="card-title text-sm">Risk by Pool</h3><div style="height:340px"><canvas ref="poolC"></canvas></div></div></div>
        <div class="card bg-base-100 border border-base-300 shadow-sm"><div class="card-body p-4"><h3 class="card-title text-sm">Key Algorithms</h3><div style="height:340px"><canvas ref="algC"></canvas></div></div></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, nextTick, onMounted } from 'vue'
import { Chart, BarController, DoughnutController, ArcElement, BarElement, CategoryScale, LinearScale, Legend, Tooltip } from 'chart.js'
import { useInventoryStore } from '../stores/inventory'

Chart.register(BarController, DoughnutController, ArcElement, BarElement, CategoryScale, LinearScale, Legend, Tooltip)
const store = useInventoryStore()
const activeTab = ref(0)
const tabs = ['Health', 'Distribution', 'Risk']
const rC = ref(null), dC = ref(null), byTypeC = ref(null), byLocC = ref(null), poolC = ref(null), algC = ref(null)
const charts = {}

function destroyCharts() { Object.values(charts).forEach(c => { if (c) c.destroy() }); charts.r = null; charts.d = null; charts.bt = null; charts.bl = null; charts.pr = null; charts.ka = null }

function renderHealth() {
    const data = store.data; if (!data?.charts?.tab0 || !rC.value || !dC.value) return
    try { const c = JSON.parse(data.charts.tab0); destroyCharts()
        if (c.radar) charts.r = new Chart(rC.value, { type: 'bar', data: { labels: c.radar.labels, datasets: [{ label: 'Immediate', data: c.radar.immediate, backgroundColor: '#ef4444', borderRadius: 4 }, { label: 'Urgent', data: c.radar.urgent, backgroundColor: '#f59e0b', borderRadius: 4 }, { label: 'Monitor', data: c.radar.monitor, backgroundColor: '#0ea5e9', borderRadius: 4 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, grid: { color: '#e5e7eb' } } }, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16 } } } } })
        if (c.health_donut) charts.d = new Chart(dC.value, { type: 'doughnut', data: { labels: c.health_donut.labels, datasets: [{ data: c.health_donut.data, backgroundColor: ['#0ea5e9', '#f59e0b', '#ef4444', '#94a3b8'], borderWidth: 0 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16 } } } } })
    } catch (e) {}
}
function renderDistribution() {
    const data = store.data; if (!data?.charts?.tab0 || !byTypeC.value || !byLocC.value) return
    try { const c = JSON.parse(data.charts.tab0); destroyCharts()
        if (c.by_type) charts.bt = new Chart(byTypeC.value, { type: 'bar', data: { labels: c.by_type.labels, datasets: [{ data: c.by_type.data, backgroundColor: '#0ea5e9', borderRadius: 4 }] }, options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, scales: { x: { grid: { color: '#e5e7eb' } }, y: { grid: { display: false } } }, plugins: { legend: { display: false } } } })
        if (c.by_location) charts.bl = new Chart(byLocC.value, { type: 'bar', data: { labels: c.by_location.labels, datasets: [{ data: c.by_location.data, backgroundColor: '#6366f1', borderRadius: 4 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { y: { grid: { color: '#e5e7eb' } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } } })
    } catch (e) {}
}
function renderRisk() {
    const data = store.data; if (!data?.charts?.tab0 || !poolC.value || !algC.value) return
    try { const c = JSON.parse(data.charts.tab0); destroyCharts()
        if (c.pool_risk) charts.pr = new Chart(poolC.value, { type: 'bar', data: { labels: c.pool_risk.labels, datasets: c.pool_risk.datasets }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, grid: { color: '#e5e7eb' } } }, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16 } } } } })
        if (c.key_alg) charts.ka = new Chart(algC.value, { type: 'doughnut', data: { labels: c.key_alg.labels, datasets: [{ data: c.key_alg.data, backgroundColor: ['#0ea5e9', '#6366f1', '#f59e0b', '#10b981', '#ec4899'], borderWidth: 0 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16 } } } } })
    } catch (e) {}
}
function renderCurrent() { destroyCharts(); nextTick(() => { if (activeTab.value === 0) renderHealth(); else if (activeTab.value === 1) renderDistribution(); else if (activeTab.value === 2) renderRisk() }) }

// Render charts when data first loads AND on tab switch
watch(() => store.data, () => { nextTick(() => renderCurrent()) }, { deep: true })
watch(activeTab, () => { nextTick(() => renderCurrent()) })
onMounted(() => { if (store.data) nextTick(() => renderCurrent()) })
</script>
