"""Application configuration — single source of truth."""
import os

# Data mode: "mock" (default) or "prod" (Google Cloud CAS)
DATA_MODE = os.getenv("DATA_MODE", "mock")

# GCP settings (only used in prod mode)
GCP_PROJECT_ID = os.getenv("GCP_PROJECT_ID", "")

# ── CA Pool Configuration ──────────────────────────────────────────
# Define your CA pools and their GCP locations here.
# Each pool can span multiple locations — the backend queries all of them.
# To add a pool:  just add it to this dict
# To remove a pool: delete it from this dict
# The frontend reads this list from /api/config/pools

CA_POOLS = {
    "prod-pool":           ["us-central1"],
    "dev-pool":            ["us-west1", "us-west3"],
    "shared-services-ca":  ["europe-west1", "asia-east1"],
    "internal-ca":         ["us-east1", "us-east4"],
    "external-ca":         ["europe-west2"],
}
# ───────────────────────────────────────────────────────────────────

# Pagination
PAGE_SIZE = 15

# Display columns for inventory table
DISPLAY_COLUMNS = [
    "Status", "Common Name (CN)", "Serial Number", "NAR ID", "Days Left",
    "Expiry Date", "Issued Date", "Resource Type", "Target Project",
    "Pool Location", "Issuer CA", "Provisioned", "Key Alg", "Signature Alg", "Source Pool"
]

# Chart colors
COLOR_MAP = {
    "Valid": "#0058ba", "Expiring": "#f59e0b", "Expired": "#ef4444",
    "ISSUED": "#0058ba", "REVOKED": "#ef4444",
}
CHART_PALETTE = ["#0058ba", "#f59e0b", "#ef4444", "#10b981", "#8b5cf6", "#ec4899", "#06b6d4", "#f97316"]
