# Certificate Hub — Development Guide

## Stack
**Backend**: FastAPI (Python 3.9+, uvicorn) — `backend/` directory
**Frontend**: Vue 3 + Vite + Pinia + Axios + Chart.js + DaisyUI 5 — `frontend/` directory

## Architecture
```
Browser (:5173) → Axios → FastAPI (:8000/api/)
```
Vue SPA handles all UI. FastAPI serves JSON. No SSR, no templates, no Django.

## Project Structure
```
backend/
├── main.py              # FastAPI app entry — CORS + routers
├── config.py            # DATA_MODE, PAGE_SIZE, colors
├── database.py          # Data layer — mock (default) or prod CAS
├── charts.py            # Chart.js data generation
├── routers/
│   ├── inventory.py     # Search, filter, paginate, cert detail
│   ├── analytics.py     # Chart data by tab (0-4)
│   └── crypto.py        # Cert/CSR decoder, format converter
└── services/
    └── cas_client.py    # Google Cloud CAS client

frontend/src/
├── App.vue              # Navbar shell
├── main.js              # createApp + Pinia + Router
├── style.css            # Quickbread theme
├── router/index.js      # 5 routes (lazy-loaded)
├── api/index.js         # Axios → localhost:8000/api
├── stores/inventory.js  # Pinia store
├── views/               # HomePage, InventoryPage, CertDecoderPage, etc.
└── components/          # FilterBar, InventoryTable, AnalyticsDashboard, CertSlideover
```

## Running
```bash
./run.sh                    # FastAPI :8000 + Vite :5173
DATA_MODE=prod ./run.sh     # Switch to Google Cloud CAS
```

## API Endpoints
| Method | Path | Purpose |
|--------|------|---------|
| POST | /api/inventory/search/ | Search (FormData) |
| GET | /api/inventory/filter/ | Multi-filter (query params) |
| GET | /api/inventory/cert/{id}/ | Cert detail |
| GET | /api/analytics/{tab_id} | Chart data |
| POST | /api/cert-decoder/decode/ | Decode PEM |
| POST | /api/csr-decoder/decode/ | Decode CSR |
| POST | /api/format-converter/convert/ | Convert format |
| GET | /api/health | Health check |

## DO NOT
- **DO NOT change the API response format** — frontend expects exact keys (count, rows, columns, charts, statuses, resource_types, locations, issuers, n24, n7, n30, pct_24h, pct_7d, pct_30d)
- **DO NOT change the quickbread theme** — defined in style.css and DESIGN.md
- **DO NOT add Django or SSR** — backend is FastAPI only, frontend is SPA only
- **DO NOT use gradient text** — solid `text-primary` only
- **DO NOT use emojis as icons** — inline SVG only
- **DO NOT add fake stats or compliance badges** — this is an internal tool

## Design
See `DESIGN.md` for full design system, theme tokens, component patterns, and typography.
