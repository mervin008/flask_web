<template>
  <div class="card bg-base-100 border border-base-300 overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300">
    <div class="overflow-x-auto">
      <table class="table table-sm table-zebra">
        <thead>
          <tr class="bg-base-200/80">
            <th v-for="col in store.columns" :key="col" class="text-[10px] font-semibold uppercase tracking-wide whitespace-nowrap">{{ col }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row,i) in store.rows" :key="i" class="hover:bg-primary/5 cursor-pointer transition-colors" @click="$emit('selectCert',row)">
            <td><span :class="['badge badge-xs font-semibold shadow-sm',badge(row.Status)]">{{ row.Status }}</span></td>
            <td class="font-mono text-[11px] whitespace-nowrap font-medium">{{ row['Common Name (CN)'] }}</td>
            <td class="font-mono text-[10px] text-base-content/50 whitespace-nowrap">{{ row['Serial Number'] }}</td>
            <td class="font-mono text-[11px]">{{ row['NAR ID'] }}</td>
            <td :class="['text-center text-[11px] font-bold',row['Days Left']<0?'text-error':row['Days Left']<30?'text-warning':'']">{{ row['Days Left'] }}d</td>
            <td class="text-[11px] text-base-content/50 whitespace-nowrap">{{ row['Expiry Date'] }}</td>
            <td class="text-[11px] text-base-content/50 whitespace-nowrap">{{ row['Issued Date'] }}</td>
            <td class="text-[11px]">{{ row['Resource Type'] }}</td>
            <td class="text-[11px]">{{ row['Target Project'] }}</td>
            <td class="text-[11px] text-base-content/50">{{ row['Pool Location'] }}</td>
            <td class="text-[11px] text-base-content/50 whitespace-nowrap">{{ row['Issuer CA'] }}</td>
            <td class="text-[11px]">{{ row['Provisioned'] }}</td>
            <td class="text-[11px] whitespace-nowrap">{{ row['Key Alg'] }}</td>
            <td class="text-[11px]">{{ row['Signature Alg'] }}</td>
            <td class="text-[11px] text-base-content/50">{{ row['Source Pool'] }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="store.totalPages>1" class="flex items-center justify-between px-4 py-2.5 border-t border-base-300 bg-base-200/30">
      <span class="text-[11px] text-base-content/50">Page {{ store.page }} of {{ store.totalPages }} · {{ store.count }} records</span>
      <div class="join shadow-sm">
        <button class="join-item btn btn-xs" :disabled="store.page<=1" @click="store.goToPage(store.page-1)">«</button>
        <button v-for="p in pages" :key="p" class="join-item btn btn-xs" :class="{'btn-active':p===store.page}" @click="typeof p==='number'&&store.goToPage(p)">{{ p }}</button>
        <button class="join-item btn btn-xs" :disabled="store.page>=store.totalPages" @click="store.goToPage(store.page+1)">»</button>
      </div>
    </div>
  </div>
</template>
<script setup>
import { computed } from 'vue'; import { useInventoryStore } from '../stores/inventory'
const store=useInventoryStore(); defineEmits(['selectCert'])
const pages=computed(()=>{const p=[];const t=store.totalPages,c=store.page;for(let i=1;i<=t;i++){if(i<=3||i>t-3||(i>=c-1&&i<=c+1))p.push(i);else if(p[p.length-1]!=='...')p.push('...')}return p})
function badge(s){const st=String(s).toLowerCase();if(st==='valid'||st==='issued'||st==='active')return'badge-success';if(st==='expiring')return'badge-warning';return'badge-error'}
</script>
