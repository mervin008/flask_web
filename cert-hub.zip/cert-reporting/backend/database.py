"""Data layer — mock data generator with same interface as real CAS client."""
from __future__ import annotations
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional
from backend.config import DATA_MODE, GCP_PROJECT_ID, CA_POOLS

# In-memory cache (shared across requests)
_cache: Optional[pd.DataFrame] = None


def get_pool_list() -> dict:
    """Return configured CA pools — called by the frontend to populate the pool selector."""
    return CA_POOLS


def search_certificates(search_type: str, search_value: str, pools: list[str], active_only: bool = True) -> pd.DataFrame:
    """Search certificates. Uses mock or real CAS based on DATA_MODE."""
    if DATA_MODE == "prod":
        return _search_prod(search_type, search_value, pools, active_only)
    return _search_mock(active_only)


def get_cached() -> pd.DataFrame | None:
    """Return cached search results."""
    return _cache


def set_cached(df: pd.DataFrame) -> None:
    """Store search results for subsequent filtering."""
    global _cache
    _cache = df


def _search_mock(active_only: bool) -> pd.DataFrame:
    """Generate realistic mock certificate data."""
    random.seed(42)
    np.random.seed(42)

    projects = ["proj-prod-01", "dev-env-x", "media-hosting", "auth-svc-prod", "shared-svcs-qa", "billing-prod"]
    res_types = ["Global External LB", "Internal LB", "GKE Ingress", "Cloud CDN", "App Engine", "GSM", "Apigee", "CloudRun"]
    issuers = ["Google Trust Services", "internal-dev-ca", "prod-root-ca-v2", "letsencrypt-v3"]
    locations = ["global", "us-central1", "europe-west1", "asia-east1", "us-east4"]
    pools = ["prod-pool", "dev-pool", "shared-pool"]

    now = datetime.now()
    records = []
    for _ in range(200):
        issued_days_ago = random.randint(1, 400)
        created = now - timedelta(days=issued_days_ago)
        lifetime_days = random.choice([90, 365, 730])
        expiry = created + timedelta(days=lifetime_days)
        days_left = (expiry - now).days
        status = "Valid" if days_left >= 30 else ("Expiring" if days_left >= 0 else "Expired")

        records.append({
            "Status": status,
            "Common Name (CN)": f"{random.choice(['api','web','svc','auth'])}.{random.choice(['prod','dev','stg'])}.internal.corp",
            "Serial Number": f"{random.randint(16,255):X}:{random.randint(16,255):X}:{random.randint(16,255):X}...",
            "NAR ID": f"NAR-{random.randint(1000, 9999)}",
            "Days Left": days_left,
            "Expiry Date": expiry.strftime("%Y-%m-%d"),
            "Issued Date": created.strftime("%Y-%m-%d"),
            "Resource Type": random.choice(res_types),
            "Target Project": random.choice(projects),
            "Pool Location": random.choice(locations),
            "Issuer CA": random.choice(issuers),
            "Provisioned": random.choice(["Google-managed", "Self-managed", "Terraform"]),
            "Key Alg": random.choice(["RSA 2048", "RSA 4096", "ECDSA P-256"]),
            "Signature Alg": "SHA256withRSA",
            "Source Pool": random.choice(pools),
            "Target Resource": f"resource-{random.randint(1, 100)}",
            "Managed By": random.choice(["CAS", "CertManager"]),
            "Lifetime (Days)": lifetime_days,
            "Month Issued": created.strftime("%Y-%m"),
            "PEM": "-----BEGIN CERTIFICATE-----\nMIIF...Mock...\n-----END CERTIFICATE-----",
            "PEM Chain": ["-----BEGIN CERTIFICATE-----\nMIIF...Mock CA Chain...\n-----END CERTIFICATE-----"],
            "SAN DNS": f"{random.choice(['api','web','svc','auth'])}.{random.choice(['prod','dev','stg'])}.internal.corp",
            "SAN IP": f"{random.randint(10,200)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}",
            "SAN URI": "",
            "SAN Email": "",
            "Auto-Renewal": "Enabled (30 days prior)" if random.choice([True, False]) else "Disabled",
            "Team ID": f"team-{random.randint(1, 50)}",
            "Create Time": created.strftime("%Y-%m-%d %H:%M:%S"),
        })

    df = pd.DataFrame(records)
    if active_only:
        df = df[df["Days Left"] >= 0]
    return df


def _search_prod(search_type: str, search_value: str, pools: list[str], active_only: bool) -> pd.DataFrame:
    """Production: query Google Cloud CAS across all configured pools and their locations."""
    try:
        from backend.services.cas_client import fetch_certificates

        filter_map = {
            "NAR ID": "nar_id", "Common Name (CN)": "cn",
            "Serial Number": "serial", "SAN": "san_dns",
        }
        all_dfs = []
        for pool in pools:
            locations = tuple(CA_POOLS.get(pool, [pool]))
            for location in locations:
                df = fetch_certificates(
                    GCP_PROJECT_ID,
                    (location,),
                    pool,
                    filter_map.get(search_type, "nar_id"),
                    search_value,
                    active_only=active_only,
                )
                if not df.empty:
                    df["Source Pool"] = pool
                    df["Pool Location"] = location
                    all_dfs.append(df)

        return pd.concat(all_dfs) if all_dfs else pd.DataFrame()
    except ImportError:
        return _search_mock(active_only)
