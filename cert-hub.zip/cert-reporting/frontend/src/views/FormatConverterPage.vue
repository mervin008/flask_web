<template>
  <div class="max-w-4xl mx-auto px-4 sm:px-6 py-8">
    <h1 class="text-3xl font-extrabold mb-1">Format Converter</h1><p class="text-base-content/50 mb-6">Convert certificates and CSRs between PEM and DER formats.</p>
    <div class="flex flex-col sm:flex-row gap-6 mb-4 p-4 bg-base-100 border border-base-300 rounded-box">
      <div><label class="text-xs font-semibold uppercase text-base-content/40 block mb-2">Type</label><div class="flex gap-3"><label class="flex items-center gap-2 cursor-pointer"><input type="radio" v-model="objType" value="cert" class="radio radio-sm radio-primary"/> Certificate</label><label class="flex items-center gap-2 cursor-pointer"><input type="radio" v-model="objType" value="csr" class="radio radio-sm radio-primary"/> CSR</label></div></div>
      <div><label class="text-xs font-semibold uppercase text-base-content/40 block mb-2">Direction</label><div class="flex gap-3"><label class="flex items-center gap-2 cursor-pointer"><input type="radio" v-model="direction" value="pem2der" class="radio radio-sm radio-primary"/> PEM → DER</label><label class="flex items-center gap-2 cursor-pointer"><input type="radio" v-model="direction" value="der2pem" class="radio radio-sm radio-primary"/> DER → PEM</label></div></div>
    </div>
    <div v-if="direction==='pem2der'"><textarea v-model="pemInput" rows="8" placeholder="-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----" class="textarea textarea-bordered w-full font-mono text-sm"></textarea><div class="flex gap-3 mt-3"><button class="btn btn-primary" @click="convert" :disabled="loading">Convert to DER</button><button class="btn btn-outline" @click="clear">Clear</button></div></div>
    <div v-else><div class="tabs tabs-boxed mb-3"><button class="tab" :class="{'tab-active':derTab==='upload'}" @click="derTab='upload'">Upload</button><button class="tab" :class="{'tab-active':derTab==='paste'}" @click="derTab='paste'">Paste Base64</button></div><input v-if="derTab==='upload'" type="file" @change="onFile" class="file-input file-input-bordered w-full"/><textarea v-else v-model="b64Input" rows="8" placeholder="Base64-encoded DER..." class="textarea textarea-bordered w-full font-mono text-sm"></textarea><div class="flex gap-3 mt-3"><button class="btn btn-primary" @click="convert" :disabled="loading">Convert to PEM</button><button class="btn btn-outline" @click="clear">Clear</button></div></div>
    <div v-if="error" class="alert alert-error mt-6">{{ error }}</div>
    <div v-if="output" class="alert alert-success mt-6">Converted</div>
    <div v-if="output" class="card bg-base-100 border border-base-300 mt-4"><div class="card-body"><h3 class="text-xs font-semibold uppercase text-base-content/40 mb-2">{{ direction==='pem2der'?'DER (Base64)':'PEM' }}</h3><pre class="text-xs font-mono text-base-content/60 max-h-64 overflow-auto">{{ output }}</pre></div></div>
  </div>
</template>
<script setup>
import { ref } from 'vue'; import { convertFormat } from '../api'
const direction=ref('pem2der'),objType=ref('cert'),pemInput=ref(''),b64Input=ref(''),derTab=ref('upload'),loading=ref(false),error=ref(null),output=ref(null)
let derBytes=null
function onFile(e){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{derBytes=r.result};r.readAsArrayBuffer(f)}
async function convert(){loading.value=true;error.value=null;output.value=null;try{const d={direction:direction.value,obj_type:objType.value};if(direction.value==='pem2der'){if(!pemInput.value.trim()){error.value='No input';return};d.pem=pemInput.value}else{if(derTab.value==='paste')d.b64=b64Input.value};const r=await convertFormat(d);output.value=r.b64_output||r.pem_output||''}catch(e){error.value=e.response?.data?.error||'Conversion failed'}finally{loading.value=false}}
function clear(){pemInput.value='';b64Input.value='';output.value=null;error.value=null}
</script>
