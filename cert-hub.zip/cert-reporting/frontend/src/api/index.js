import axios from 'axios'
const api = axios.create({
  baseURL: 'http://localhost:8000/api',
  paramsSerializer: p => Object.entries(p).filter(([,v])=>v!==undefined&&v!==null&&v!=='').map(([k,v])=>k+'='+encodeURIComponent(Array.isArray(v)?v.join(','):v)).join('&')
})
export const searchInventory = p => api.post('/inventory/search/', p).then(r=>r.data)
export const filterInventory = p => api.get('/inventory/filter/', { params:p }).then(r=>r.data)
export const decodeCert = pem => api.post('/cert-decoder/decode/', { pem }).then(r=>r.data)
export const decodeCsr = pem => api.post('/csr-decoder/decode/', { pem }).then(r=>r.data)
export const convertFormat = d => api.post('/format-converter/convert/', d).then(r=>r.data)
export const getPoolConfig = () => api.get('/config/pools').then(r=>r.data)
export default api
