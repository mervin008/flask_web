import { defineStore } from 'pinia'; import { ref, computed } from 'vue'; import { searchInventory, filterInventory } from '../api'
export const useInventoryStore = defineStore('inventory', () => {
  const loading=ref(false),error=ref(null),data=ref(null),searchType=ref('NAR ID'),searchValue=ref(''),activeFilters=ref({}),selectedPools=ref(['prod-pool'])
  const originalOptions=ref({statuses:[],resource_types:[],locations:[],issuers:[]})
  const count=computed(()=>data.value?.count??0),rows=computed(()=>data.value?.rows??[])
  const columns=computed(()=>data.value?.columns??[]),page=computed(()=>data.value?.page??1),totalPages=computed(()=>data.value?.total_pages??1)
  async function search(type,value,pools=null){
    loading.value=true;error.value=null;searchType.value=type;searchValue.value=value
    if(pools)selectedPools.value=pools
    try{
      const f=new FormData();f.append('search_type',type);f.append('search_value',value);f.append('active_only','true')
      selectedPools.value.forEach(p=>f.append('pools',p))
      data.value=await searchInventory(f);activeFilters.value={}
      originalOptions.value={statuses:[...data.value.statuses],resource_types:[...data.value.resource_types],locations:[...data.value.locations],issuers:[...data.value.issuers]}
    }catch(e){error.value=e.response?.data?.error||e.message}finally{loading.value=false}
  }
  async function filter(filters={},pg=1){loading.value=true;error.value=null;try{data.value=await filterInventory({search_value:searchValue.value,search_type:searchType.value,page:pg,...filters});activeFilters.value=filters}catch(e){error.value=e.response?.data?.error||e.message}finally{loading.value=false}}
  async function goToPage(pg){await filter(activeFilters.value,pg)}
  function clearFilters(){activeFilters.value={};filter({})}
  function toggleFilter(key,val){const cur=new Set(activeFilters.value[key]||[]);cur.has(val)?cur.delete(val):cur.add(val);const next={...activeFilters.value,[key]:[...cur]};if(!cur.size)delete next[key];filter(next)}
  function removeFilterTag(key,val){const cur=(activeFilters.value[key]||[]).filter(v=>v!==val);const next={...activeFilters.value,[key]:cur};if(!cur.length)delete next[key];filter(next)}
  return{loading,error,data,searchType,searchValue,activeFilters,selectedPools,originalOptions,count,rows,columns,page,totalPages,search,filter,goToPage,clearFilters,toggleFilter,removeFilterTag}
})
