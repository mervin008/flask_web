<template>
  <div class="space-y-3">
    <div class="flex items-center gap-2 flex-wrap">
      <span class="text-xs text-base-content/50 font-medium flex items-center gap-1">
        <svg class="size-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/></svg>
        {{ store.count }} results
      </span>
      <span v-for="(v,vi) in activeTagList" :key="vi" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20 cursor-pointer hover:bg-error/10 hover:text-error hover:border-error/20 transition-all duration-150 shadow-sm" @click="store.removeFilterTag(v.k,v.v)">{{ v.v }} <span class="text-[11px] leading-none font-bold">&times;</span></span>
      <button v-if="totalActive" class="text-[11px] text-error font-semibold hover:underline ml-1" @click="store.clearFilters()">Clear all</button>
    </div>
    <div class="flex items-center gap-1.5 flex-wrap">
      <div v-for="f in filters" :key="f.key" class="relative">
        <button @click="openFilter=openFilter===f.key?null:f.key" :class="['btn btn-xs gap-1.5 transition-all duration-150',openFilter===f.key||counts[f.key]>0?'btn-primary btn-outline border-2 shadow-sm':'btn-ghost border border-base-300 hover:border-base-content/20']" :title="'Filter by '+f.label">
          <span class="w-1.5 h-1.5 rounded-full" :class="counts[f.key]>0?'bg-primary':'bg-base-content/20'"></span>{{ f.label }}
          <span v-if="counts[f.key]" class="badge badge-xs badge-primary font-bold shadow-sm">{{ counts[f.key] }}</span>
          <svg class="size-3 transition-transform duration-200" :class="openFilter===f.key?'rotate-180':''" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <Transition name="dropdown">
          <div v-if="openFilter===f.key" class="absolute top-full mt-1 left-0 z-50 bg-base-100 border border-base-300 rounded-box shadow-xl w-56" @click.stop>
            <div class="p-2 border-b border-base-200"><input type="text" class="input input-bordered input-xs w-full" :placeholder="'Search...'" v-model="searchTerms[f.key]" @click.stop @input.stop/></div>
            <div class="flex gap-1 px-2 py-1 border-b border-base-200"><button class="btn btn-ghost btn-xs flex-1 text-[10px]" @click.stop="selectAll(f.key,true)">All</button><button class="btn btn-ghost btn-xs flex-1 text-[10px]" @click.stop="selectAll(f.key,false)">None</button></div>
            <div class="max-h-56 overflow-y-auto p-1"><label v-for="opt in filtered(f)" :key="opt" class="flex items-center gap-2 px-2 py-1.5 hover:bg-base-200 rounded-md cursor-pointer text-xs transition-colors" @click.stop><input type="checkbox" :checked="isActive(f.key,opt)" @change="store.toggleFilter(f.key,opt)" class="checkbox checkbox-primary checkbox-xs"/><span class="select-none">{{ opt }}</span></label></div>
          </div>
        </Transition>
      </div>
    </div>
    <div v-if="openFilter" class="fixed inset-0 z-40" @click="openFilter=null"></div>
  </div>
</template>
<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'; import { useInventoryStore } from '../stores/inventory'
const store=useInventoryStore(); const openFilter=ref(null); const searchTerms=reactive({})
const filters=[{key:'status',label:'Status'},{key:'resource_type',label:'Resource Type'},{key:'location',label:'Location'},{key:'issuer',label:'Issuer'}]
const counts=computed(()=>{const c={};filters.forEach(f=>{c[f.key]=(store.activeFilters[f.key]||[]).length});return c})
const totalActive=computed(()=>Object.values(counts.value).reduce((a,b)=>a+b,0))
const activeTagList=computed(()=>{const t=[];Object.entries(store.activeFilters).forEach(([k,vs])=>{vs.forEach(v=>t.push({k,v}))});return t})
function isActive(key,val){return(store.activeFilters[key]||[]).includes(val)}
function selectAll(key,all){const m={status:'statuses',resource_type:'resource_types',location:'locations',issuer:'issuers'};const o=store.originalOptions?.[m[key]]||[];store.filter({...store.activeFilters,[key]:all?[...o]:[]})}
function filtered(f){const m={status:'statuses',resource_type:'resource_types',location:'locations',issuer:'issuers'};const all=store.originalOptions?.[m[f.key]]||[];const t=(searchTerms[f.key]||'').toLowerCase();return t?all.filter(o=>o.toLowerCase().includes(t)):all}
function onKey(e){if(e.key==='Escape')openFilter.value=null}
onMounted(()=>document.addEventListener('keydown',onKey))
onUnmounted(()=>document.removeEventListener('keydown',onKey))
</script>
<style scoped>
.dropdown-enter-active, .dropdown-leave-active { transition: opacity 0.15s ease, transform 0.15s ease; }
.dropdown-enter-from, .dropdown-leave-to { opacity: 0; transform: translateY(-4px) scale(0.97); }
</style>
