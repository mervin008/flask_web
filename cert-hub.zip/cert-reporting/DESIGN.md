# Certificate Hub — Design System

## Theme: Quickbread
```css
@plugin "daisyui/theme" {
  name: "quickbread";
  --color-primary: oklch(48% 0.18 255);        /* Navy blue */
  --color-primary-content: oklch(98% 0 0);      /* White on primary */
  --color-secondary: oklch(83% 0.145 321.434);   /* Soft purple */
  --color-accent: oklch(87% 0.01 258.338);       /* Blue-gray */
  --color-neutral: oklch(37% 0.044 257.287);     /* Dark slate */
  --color-base-100: oklch(98% 0.003 247.858);    /* Near-white bg */
  --color-base-200: oklch(96% 0.007 247.896);    /* Page bg */
  --color-base-300: oklch(92% 0.013 255.508);    /* Borders */
  --color-base-content: oklch(20% 0.042 265.755);/* Text */
  --color-success: oklch(79% 0.209 151.711);     /* Green */
  --color-warning: oklch(82% 0.189 84.429);      /* Amber */
  --color-error: oklch(70% 0.191 22.216);        /* Red */
  --radius-box: 0.5rem; --radius-field: 0.5rem;
}
```

## Typography
- **Font**: Plus Jakarta Sans (weights 400–800)
- **Headings**: `font-extrabold tracking-tight`
- **Body**: `text-sm leading-relaxed`
- **Labels**: `text-[10px] font-semibold uppercase tracking-wider`
- **Data/Mono**: `font-mono text-[10px]` or `text-[11px]`
- **Primary color**: `text-primary` (solid, no gradients)

## Components

### Buttons
- Primary: `btn btn-primary btn-sm shadow-sm hover:shadow-md transition-all`
- Ghost: `btn btn-ghost btn-xs`
- Outline: `btn btn-outline btn-xs`
- Active: `btn-active` (via Vue Router `active-class`)

### Cards
- `card bg-base-100 border border-base-300 shadow-sm hover:shadow-md transition-shadow`

### Tables
- `table table-sm table-zebra`
- Header: `text-[10px] font-semibold uppercase tracking-wide`
- Rows: `hover:bg-primary/5 cursor-pointer`
- Pagination: `join` with `btn-xs`

### Badges
- Status: `badge badge-xs font-semibold` + `badge-success/warning/error`
- Filter tags: `px-2.5 py-1 rounded-full bg-primary/10 text-primary border-primary/20`
- Count: `badge badge-xs badge-primary font-bold`

### Filters
- Trigger: `btn btn-xs gap-1.5 btn-primary btn-outline border-2` (active) / `btn-ghost border border-base-300` (inactive)
- Dropdown: `absolute bg-base-100 border rounded-box shadow-xl w-56`
- Checkbox: `checkbox checkbox-primary checkbox-xs`
- Active tags: removable chips with `hover:bg-error/10` on hover
- Original options cached — dropdowns NEVER shrink when filtering

### Analytics
- KPI cards with `progress` bars
- Chart.js with fixed-height containers (`style="height:260px"`)
- 3 tabs: Health (KPIs + bar + donut), Distribution (horizontal bars), Risk (stacked bar + donut)

### Slideover
- `<Teleport to="body">` + backdrop overlay
- 2-column grid layout, sections with border dividers

### Tooltips
- `tooltip tooltip-bottom` with `data-tip`

## Icons
- Inline SVG only (no icon libraries, no emojis)
- `size-3.5` (info), `size-4` (buttons), `size-5+` (hero)
- `stroke-width="1.5"` or `"2"`, `stroke="currentColor"`

## Spacing
- Page: `px-4 sm:px-6 py-6 space-y-4`
- Cards: `p-4` or `p-5`
- Gaps: `gap-3` or `gap-4`

## DO NOT
- Use gradient text (solid `text-primary` only)
- Use emojis as icons (inline SVG only)
- Add compliance badges or fake stats
- Change the theme without updating this file
