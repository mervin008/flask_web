# Certificate Hub

Enterprise-grade TLS certificate management dashboard for Google Cloud Certificate Authority Service. Search, filter, inspect, and download certificates across your CA pools.

## Architecture

```
Browser (:5173) → Axios → FastAPI (:8000) → Google Cloud CAS (prod) / Mock data (dev)
```

Vue 3 SPA handles all UI. FastAPI serves JSON API endpoints. No SSR, no templates, no database.

## Quick Start

### Prerequisites
- **Python 3.9+** with `pip`
- **Node.js 18+** with `npm`

### Install & Run

```bash
cd cert-reporting

# Backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Frontend
cd frontend && npm install && cd ..

# Start both
./run.sh
```

Open **http://localhost:5173**

### Switch to Production (Google Cloud CAS)

```bash
DATA_MODE=prod GCP_PROJECT_ID=my-project-id ./run.sh
```

Requires `google-cloud-security-private-ca` installed and GCP credentials configured.

## Configuration

All settings in **`backend/config.py`** — single source of truth:

```python
CA_POOLS = {
    "prod-pool":           ["us-central1"],
    "dev-pool":            ["us-west1", "us-west3"],
    "shared-services-ca":  ["europe-west1", "asia-east1"],
}
```

Add/remove pools here. Each pool can span multiple GCP locations. The frontend fetches this list automatically from `/api/config/pools`.

## Project Structure

```
├── README.md
├── CLAUDE.md                 # Developer guide
├── DESIGN.md                 # Design system
├── requirements.txt
├── run.sh
│
├── backend/                  # FastAPI
│   ├── main.py               #   Entry — CORS, routers, /api/config/pools
│   ├── config.py             #   ⚙️ CA_POOLS, PAGE_SIZE, colors — EDIT THIS
│   ├── database.py           #   Data layer — mock or prod CAS
│   ├── charts.py             #   Chart.js data generation
│   ├── routers/
│   │   ├── inventory.py      #   Search, filter, paginate, cert detail
│   │   ├── analytics.py      #   Chart data by tab
│   │   └── crypto.py         #   Cert/CSR decoder, format converter
│   └── services/
│       └── cas_client.py     #   Google CAS client (PEM + chain extraction)
│
└── frontend/                 # Vue 3 SPA
    └── src/
        ├── App.vue           #   Navbar + router-view
        ├── style.css         #   Quickbread theme
        ├── router/index.js   #   5 routes
        ├── api/index.js      #   Axios client
        ├── stores/
        │   └── inventory.js  #   Pinia store
        ├── views/
        │   ├── HomePage.vue
        │   ├── InventoryPage.vue      # Search + CA pool selector + filters + table
        │   ├── CertDecoderPage.vue
        │   ├── CsrcDecoderPage.vue
        │   └── FormatConverterPage.vue
        └── components/
            ├── FilterBar.vue          # Multi-select dropdowns
            ├── InventoryTable.vue     # 15-row table + pagination
            ├── AnalyticsDashboard.vue # 3 tabs (Health, Distribution, Risk)
            └── CertSlideover.vue      # Slide-over + PEM/Chain downloads
```

## API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| POST | /api/inventory/search/ | Search certs (FormData) |
| GET | /api/inventory/filter/ | Multi-filter (comma-separated query params) |
| GET | /api/inventory/cert/{id} | Single cert detail |
| GET | /api/analytics/{tab} | Chart data (Health/Distribution/Risk) |
| POST | /api/cert-decoder/decode/ | Decode PEM certificate |
| POST | /api/csr-decoder/decode/ | Decode PEM CSR |
| POST | /api/format-converter/convert/ | Convert PEM ↔ DER |
| GET | /api/config/pools | CA pool list for frontend |
| GET | /api/health | Health check |

## Features

- **CA Pool Selector** — multi-select dropdown, pools loaded from backend config
- **Multi-Select Filters** — Status, Resource Type, Location, Issuer with search, All/None, count badges
- **Data Table** — 15 rows per page, zebra stripes, hover highlight, pagination
- **Certificate Detail** — 2-column slide-over, PEM + PEM Chain download buttons
- **Analytics** — 3 tabs (Health monitor, Distribution, Risk analysis) with Chart.js
- **Crypto Tools** — Cert decoder, CSR decoder (with OpenSSL fallback), Format converter

## Key Design Decisions

- **Vue SPA (not SSR)**: Filter multi-select state is complex — Pinia makes it trivial
- **FastAPI (not Django)**: Lighter, async-native, built-in OIDC/OAuth2
- **15 rows/page**: Fits 1080p without scrolling, 14 pages max for 200 results
- **originalOptions pattern**: Filter dropdowns never shrink — prevents UX bug where filtering hides options you want next
- **paramsSerializer**: Arrays joined with commas — Django-compatible format
- **CA_POOLS in config.py**: Single source of truth, frontend fetches dynamically

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Port in use | `run.sh` kills existing :8000/:5173 before starting |
| Vite 404 | Must run from `frontend/` directory |
| Blank page | Backend must be running — check `:8000/api/health` |
| Charts not loading | Click "View Analytics" below the table after search |
| Wrong pool locations | Edit `CA_POOLS` in `backend/config.py` and restart |

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.9+, FastAPI, Uvicorn, Pandas, Cryptography |
| Frontend | Vue 3, Vite, Pinia, Vue Router, Axios |
| UI | DaisyUI 5, Tailwind CSS 4, Chart.js |
| Font | Plus Jakarta Sans (Google Fonts) |
| Icons | Inline SVG |
