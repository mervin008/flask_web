"""Google Cloud CAS client — production data fetcher."""
from __future__ import annotations
import logging
import time
import pandas as pd
from datetime import datetime, timezone
from typing import Optional
from google.cloud.security import privateca_v1

logger = logging.getLogger(__name__)

FILTER_MAP = {
    "nar_id": 'labels.nar_id="{value}"',
    "cn": 'certificate_description.subject_description.subject.common_name="{value}"',
    "serial": 'certificate_description.subject_description.hex_serial_number="{value}"',
    "san_dns": 'certificate_description.subject_description.subject_alt_name.dns_names:"{value}"',
}

_client = None


def _get_client():
    global _client
    if _client is None:
        _client = privateca_v1.CertificateAuthorityServiceClient()
    return _client


def fetch_certificates(
    project_id: str,
    locations: tuple,
    ca_pool_id: str,
    filter_type: Optional[str] = None,
    filter_value: Optional[str] = None,
    active_only: bool = False,
) -> pd.DataFrame:
    """Fetch certificates from Google CAS with optional server-side filtering."""
    start = time.time()
    cert_data = []
    api_filter = _build_filter(filter_type, filter_value, active_only)

    if api_filter:
        logger.info("CAS filter: %s", api_filter)

    client = _get_client()
    for location in locations:
        try:
            parent = client.ca_pool_path(project_id, location, ca_pool_id)
            request = privateca_v1.ListCertificatesRequest(parent=parent, filter=api_filter)
            for cert in client.list_certificates(request=request):
                cert_data.append(_flatten(cert, location))
        except Exception as e:
            logger.error("Error fetching from %s: %s", location, e)

    elapsed = round(time.time() - start, 2)
    logger.info("Fetched %d certs across %d locations in %ss", len(cert_data), len(locations), elapsed)
    return pd.DataFrame(cert_data)


def _build_filter(filter_type, filter_value, active_only):
    parts = []
    if filter_type and filter_value:
        template = FILTER_MAP.get(filter_type)
        if template:
            parts.append(template.format(value=filter_value))
    if active_only:
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        parts.append(f'certificate_description.subject_description.not_after_time > "{now_iso}"')
    return " AND ".join(parts) if parts else None


def _flatten(cert, location: str) -> dict:
    desc = cert.certificate_description
    subj_desc = desc.subject_description if desc else None
    subj = subj_desc.subject if subj_desc else None
    labels = dict(cert.labels) if cert.labels else {}
    san = desc.subject_alt_name if desc else None
    pubkey = desc.public_key if desc else None

    # SANs
    san_dns = ", ".join(san.dns_names) if san and san.dns_names else None
    san_ip = ", ".join(san.ip_addresses) if san and san.ip_addresses else None
    san_uri = ", ".join(san.uris) if san and san.uris else None
    san_email = ", ".join(san.email_addresses) if san and san.email_addresses else None

    # Lifetime
    lifetime_str = str(subj_desc.lifetime) if subj_desc and subj_desc.lifetime else None

    # PEM
    pem_cert = cert.pem_certificate if cert.pem_certificate else None
    pem_chain = cert.pem_certificate_chain if cert.pem_certificate_chain else []

    return {
        "Status": "REVOKED" if cert.revocation_details else "ISSUED",
        "Common Name (CN)": subj.common_name if subj else None,
        "Serial Number": subj_desc.hex_serial_number if subj_desc else None,
        "NAR ID": labels.get("nar_id", "N/A"),
        "Target Resource": labels.get("target_resource", "N/A"),
        "Target Project": labels.get("target_project", "N/A"),
        "Resource Type": labels.get("resource_type", "N/A"),
        "Provisioned": labels.get("provisioned", "N/A"),
        "Pool Location": location,
        "Issuer CA": cert.issuer_certificate_authority.split("/")[-1] if cert.issuer_certificate_authority else None,
        "Issued Date": subj_desc.not_before_time.strftime("%Y-%m-%d %H:%M:%S") if subj_desc and subj_desc.not_before_time else None,
        "Expiry Date": subj_desc.not_after_time.strftime("%Y-%m-%d %H:%M:%S") if subj_desc and subj_desc.not_after_time else None,
        "Days Left": (subj_desc.not_after_time - datetime.now(timezone.utc)).days if subj_desc and subj_desc.not_after_time else None,
        "Key Alg": pubkey.key_format.name if pubkey and hasattr(pubkey, 'key_format') else None,
        "Signature Alg": desc.signature_algorithm.name if desc and hasattr(desc, 'signature_algorithm') else None,
        "SAN DNS": san_dns,
        "SAN IP": san_ip,
        "SAN URI": san_uri,
        "SAN Email": san_email,
        "Lifetime": lifetime_str,
        "Auto-Renewal": labels.get("auto_renewal", "Disabled"),
        "Team ID": labels.get("team_id", ""),
        "Source Pool": cert.name.split("/caPools/")[1].split("/")[0] if cert.name and "/caPools/" in cert.name else None,
        "Create Time": cert.create_time.strftime("%Y-%m-%d %H:%M:%S") if cert.create_time else None,
        # PEM downloads
        "PEM": pem_cert,
        "PEM Chain": pem_chain,
    }
