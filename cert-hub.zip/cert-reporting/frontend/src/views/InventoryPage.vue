<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-5">
    <div class="flex flex-wrap items-end justify-between gap-3">
      <div>
        <div class="text-sm breadcrumbs"><ul><li>CMS Console</li><li class="text-primary font-semibold">CAS Inventory</li></ul></div>
        <div class="flex items-center gap-2">
          <h1 class="text-2xl font-extrabold tracking-tight">Certificate Inventory</h1>
          <div class="tooltip tooltip-bottom" data-tip="Search and manage certificates across Google Cloud CA pools">
            <svg class="size-4 text-base-content/30 cursor-help" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
        </div>
      </div>
      <button class="btn btn-outline btn-sm gap-1" @click="exportCSV">
        <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg> Export
      </button>
    </div>

    <div class="card bg-base-100 border border-base-300 shadow-sm hover:shadow-md transition-shadow duration-300">
      <div class="card-body p-5 gap-4">
        <div class="flex items-center gap-2">
          <span class="text-xs font-semibold text-base-content/40 uppercase tracking-wider">Search by</span>
          <div class="flex gap-1 flex-wrap">
            <button v-for="t in ['NAR ID','Common Name (CN)','Serial Number','SAN']" :key="t" @click="store.searchType=t" :class="['btn btn-xs transition-all duration-150',store.searchType===t?'btn-primary shadow-sm':'btn-ghost']">{{ t }}</button>
          </div>
        </div>
        <div class="flex gap-2 items-end">
          <div class="form-control flex-1">
            <input v-model="searchInput" placeholder="Enter search query..." class="input input-bordered input-sm w-full focus:border-primary transition-colors" @keyup.enter="doSearch"/>
          </div>
          <div class="flex items-center gap-1">
            <label class="flex items-center gap-2 cursor-pointer px-1">
              <input type="checkbox" v-model="activeOnly" class="toggle toggle-primary toggle-sm"/>
              <span class="text-xs font-medium">Active only</span>
            </label>
            <div class="tooltip tooltip-bottom" data-tip="Show only non-expired certificates. Uncheck to include expired certs in results.">
              <svg class="size-3.5 text-base-content/25 cursor-help" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
          </div>
          <button class="btn btn-primary btn-sm gap-1 shadow-sm hover:shadow-md transition-all duration-150" @click="doSearch" :disabled="store.loading">
            <span v-if="store.loading" class="loading loading-spinner loading-sm"></span>
            <svg v-else class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            Search
          </button>
        </div>
        <!-- CA Pool multi-select -->
        <div class="flex items-center gap-2 pt-1 border-t border-base-200">
          <div class="flex items-center gap-1.5 text-xs font-semibold text-base-content/40 uppercase tracking-wider">
            <svg class="size-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            CA Pools
          </div>
          <div class="flex flex-wrap gap-1.5 items-center">
            <div class="relative">
              <button @click="poolOpen=!poolOpen" :class="['btn btn-xs gap-1 transition-all', poolOpen||store.selectedPools.length?'btn-primary btn-outline shadow-sm':'btn-ghost border border-base-300 hover:border-base-content/20']" :title="'Choose which CA pools to search across'">
                <svg class="size-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
                {{ store.selectedPools.length ? store.selectedPools.length+' pools' : 'Add pool' }}
              </button>
              <Transition name="dropdown">
                <div v-if="poolOpen" class="absolute top-full mt-1 left-0 z-50 bg-base-100 border border-base-300 rounded-box shadow-xl w-52" @click.stop>
                  <div class="p-1 max-h-56 overflow-y-auto">
                    <label v-for="p in poolOptions" :key="p" class="flex items-center gap-2 px-2 py-1.5 hover:bg-base-200 rounded-md cursor-pointer text-xs transition-colors" @click.stop>
                      <input type="checkbox" :value="p" v-model="store.selectedPools" @change="ensurePoolSelection" class="checkbox checkbox-primary checkbox-xs"/>
                      <span>{{ p }}</span>
                    </label>
                  </div>
                </div>
              </Transition>
            </div>
            <span v-for="p in store.selectedPools" :key="p" class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-primary/10 text-primary border border-primary/20 cursor-pointer hover:bg-error/10 hover:text-error hover:border-error/20 transition-all duration-150" @click="store.selectedPools=store.selectedPools.filter(x=>x!==p)">{{ p }} <span class="text-[10px] leading-none font-bold">&times;</span></span>
          </div>
        </div>
        <div v-if="poolOpen" class="fixed inset-0 z-40" @click="poolOpen=false"></div>
      </div>
    </div>

    <div v-if="store.error" class="alert alert-error shadow-sm">{{ store.error }}</div>

    <template v-if="store.data">
      <FilterBar />
      <InventoryTable @select-cert="selectedCert=$event" />
      <!-- View Analytics toggle -->
      <div v-if="!showAnalytics" class="text-center">
        <button class="btn btn-ghost btn-sm gap-2" @click="showAnalytics=true">
          <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
          View Analytics
        </button>
      </div>
      <AnalyticsDashboard v-if="showAnalytics" />
    </template>

    <div v-else-if="!store.loading" class="card bg-base-100 border border-base-300">
      <div class="card-body items-center py-20 text-base-content/20">
        <svg class="size-20 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="0.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <p class="text-lg font-medium">Enter search criteria and click Search</p>
      </div>
    </div>

    <CertSlideover v-if="selectedCert" :cert="selectedCert" @close="selectedCert=null" />
  </div>
</template>
<script setup>
import { ref, onMounted, onUnmounted } from 'vue'; import { useInventoryStore } from '../stores/inventory'
import { getPoolConfig } from '../api'
import FilterBar from '../components/FilterBar.vue'; import InventoryTable from '../components/InventoryTable.vue'
import AnalyticsDashboard from '../components/AnalyticsDashboard.vue'; import CertSlideover from '../components/CertSlideover.vue'
const store=useInventoryStore(); const searchInput=ref(''); const activeOnly=ref(true); const selectedCert=ref(null); const poolOpen=ref(false); const showAnalytics=ref(false)
const poolOptions=ref(['prod-pool'])
onMounted(async ()=>{ try { const pools=await getPoolConfig(); poolOptions.value=Object.keys(pools); if(!store.selectedPools.length) store.selectedPools=[poolOptions.value[0]] } catch(e){ /* keep defaults */ } })
function ensurePoolSelection(){ if(store.selectedPools.length===0) store.selectedPools=['prod-pool'] }
function doSearch(){ if(!searchInput.value.trim()) return; showAnalytics.value=false; store.search(store.searchType,searchInput.value) }
function exportCSV(){ if(!store.rows?.length)return; const c=store.columns; const csv=[c.join(','),...store.rows.map(r=>c.map(x=>'"'+(r[x]||'').replace(/"/g,'""')+'"').join(','))].join('\n'); const b=new Blob([csv]); const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='certs.csv'; a.click() }
function onKey(e){ if(e.key==='Escape') poolOpen.value=false }
onMounted(()=>document.addEventListener('keydown',onKey))
onUnmounted(()=>document.removeEventListener('keydown',onKey))
</script>
<style scoped>
.dropdown-enter-active, .dropdown-leave-active { transition: opacity 0.15s ease, transform 0.15s ease; }
.dropdown-enter-from, .dropdown-leave-to { opacity: 0; transform: translateY(-4px) scale(0.97); }
</style>
