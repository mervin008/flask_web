"""Chart.js data generation."""
import json
import numpy as np
import pandas as pd
from backend.config import COLOR_MAP, CHART_PALETTE


def build_all(df: pd.DataFrame) -> dict:
    """Generate all chart data as JSON-serializable dict."""
    if df.empty:
        return {"tab0": "{}"}

    c = {}
    c.update(_health_monitor(df))
    c.update(_distribution(df))
    c.update(_time_analysis(df))
    c.update(_architecture(df))
    c.update(_deep_drill(df))

    return {"tab0": json.dumps(c)}


def _health_monitor(df: pd.DataFrame) -> dict:
    charts = {}
    radar_df = df[(df["Days Left"] >= 0) & (df["Days Left"] <= 90)].copy()
    if not radar_df.empty:
        radar_df["Risk"] = np.where(
            radar_df["Days Left"] <= 7, "Immediate",
            np.where(radar_df["Days Left"] <= 30, "Urgent", "Monitor")
        )
        grouped = radar_df.groupby(["Days Left", "Risk"]).size().reset_index(name="Count")
        days = sorted(map(int, grouped["Days Left"].unique().tolist()))

        def get(risk, day):
            mask = (grouped["Days Left"] == day) & (grouped["Risk"] == risk)
            return int(grouped[mask]["Count"].sum()) if not grouped[mask].empty else 0

        charts["radar"] = {
            "labels": days,
            "immediate": [get("Immediate", d) for d in days],
            "urgent": [get("Urgent", d) for d in days],
            "monitor": [get("Monitor", d) for d in days],
        }

    vc = df["Status"].value_counts()
    charts["health_donut"] = {"labels": vc.index.tolist(), "data": [int(x) for x in vc.values]}

    pr = df.groupby(["Source Pool", "Status"]).size().unstack(fill_value=0)
    charts["pool_risk"] = {
        "labels": pr.index.tolist(),
        "datasets": [
            {"label": s, "data": [int(x) for x in pr[s]], "backgroundColor": COLOR_MAP.get(s, "#94a3b8")}
            for s in pr.columns
        ]
    }
    return charts


def _distribution(df: pd.DataFrame) -> dict:
    rt = df["Resource Type"].value_counts()
    tp = df["Target Project"].value_counts()
    pl = df["Pool Location"].value_counts()
    return {
        "by_type": {"labels": rt.index.tolist(), "data": [int(x) for x in rt.values]},
        "by_project": {"labels": tp.index.tolist(), "data": [int(x) for x in tp.values]},
        "by_location": {"labels": pl.index.tolist(), "data": [int(x) for x in pl.values]},
    }


def _time_analysis(df: pd.DataFrame) -> dict:
    m = df.groupby("Month Issued").size().sort_index()
    lt = df["Lifetime (Days)"].value_counts().sort_index()
    return {
        "issuance_trend": {"labels": m.index.tolist(), "data": [int(x) for x in m.values]},
        "lifetime_dist": {"labels": [str(k) for k in lt.index], "data": [int(x) for x in lt.values]},
    }


def _architecture(df: pd.DataFrame) -> dict:
    charts = {}
    for key, col in [("key_alg", "Key Alg"), ("geo_donut", "Pool Location"), ("managed_by", "Managed By")]:
        vc = df[col].value_counts()
        charts[key] = {"labels": vc.index.tolist(), "data": [int(x) for x in vc.values]}
    return charts


def _deep_drill(df: pd.DataFrame) -> dict:
    rt = df.groupby(["Resource Type", "Status"]).size().unstack(fill_value=0)
    pj = df.groupby(["Target Project", "Status"]).size().unstack(fill_value=0)
    return {
        "rt_status": {
            "labels": rt.index.tolist(),
            "datasets": [
                {"label": s, "data": [int(x) for x in rt[s]],
                 "backgroundColor": COLOR_MAP.get(s, CHART_PALETTE[i % len(CHART_PALETTE)])}
                for i, s in enumerate(rt.columns)
            ]
        },
        "pj_status": {
            "labels": pj.index.tolist(),
            "datasets": [
                {"label": s, "data": [int(x) for x in pj[s]],
                 "backgroundColor": COLOR_MAP.get(s, CHART_PALETTE[i % len(CHART_PALETTE)])}
                for i, s in enumerate(pj.columns)
            ]
        }
    }
