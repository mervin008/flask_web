<template>
  <div class="min-h-screen bg-gradient-to-br from-base-200 via-base-100 to-base-200">
    <div class="navbar bg-base-100/80 backdrop-blur shadow-sm sticky top-0 z-50 border-b border-base-300/50 px-6">
      <div class="flex-1">
        <router-link to="/" class="btn btn-ghost text-xl font-bold tracking-tight no-underline hover:bg-base-200">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-md"><span class="text-xs font-bold text-primary-content">CH</span></div>
          <span class="ml-2 text-primary font-extrabold">CertHub</span>
        </router-link>
      </div>
      <div class="flex gap-1">
        <router-link v-for="l in nav" :key="l.path" :to="l.path" class="btn btn-ghost btn-sm group relative" active-class="btn-active">
          {{ l.label }}
          <div class="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-primary rounded group-hover:w-3/4 transition-all duration-200"></div>
        </router-link>
        <div class="ml-4 flex items-center gap-2 px-3 py-1 rounded-full bg-success/10 text-success text-xs font-semibold border border-success/20">
          <span class="w-2 h-2 rounded-full bg-success animate-pulse shadow-sm shadow-success"></span>GCP Connected
        </div>
      </div>
    </div>
    <router-view />
  </div>
</template>
<script setup>
const nav = [{ path:'/',label:'Home'},{ path:'/inventory',label:'Inventory'},{ path:'/csr-decoder',label:'CSR'},{ path:'/cert-decoder',label:'Cert'},{ path:'/format-converter',label:'Convert'}]
</script>
