import { createRouter, createWebHistory } from 'vue-router'
export default createRouter({ history: createWebHistory(), routes: [
  { path:'/', name:'home', component:()=>import('../views/HomePage.vue') },
  { path:'/inventory', name:'inventory', component:()=>import('../views/InventoryPage.vue') },
  { path:'/cert-decoder', name:'cert-decoder', component:()=>import('../views/CertDecoderPage.vue') },
  { path:'/csr-decoder', name:'csr-decoder', component:()=>import('../views/CsrDecoderPage.vue') },
  { path:'/format-converter', name:'converter', component:()=>import('../views/FormatConverterPage.vue') },
]})
