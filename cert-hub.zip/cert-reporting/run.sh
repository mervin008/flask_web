#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"

# Kill existing
lsof -ti:8000 | xargs kill -9 2>/dev/null
lsof -ti:5173 | xargs kill -9 2>/dev/null
sleep 1

echo "FastAPI :8000 | Vue :5173"
cd "$DIR" && "$DIR/.venv/bin/python" -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload &
API=$!
cd "$DIR/frontend" && npx vite --port 5173 --strictPort &
VUE=$!
trap "kill $API $VUE 2>/dev/null" EXIT
wait
