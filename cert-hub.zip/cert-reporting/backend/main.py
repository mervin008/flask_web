"""Certificate Hub API — FastAPI application entry point."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routers import inventory, analytics, crypto

app = FastAPI(title="Certificate Hub API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(inventory.router)
app.include_router(analytics.router)
app.include_router(crypto.router)


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.get("/api/config/pools")
async def config_pools():
    """Return configured CA pools and their locations for the frontend."""
    from backend.config import CA_POOLS
    return CA_POOLS


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
