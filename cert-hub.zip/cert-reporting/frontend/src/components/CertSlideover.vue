<template>
  <Teleport to="body">
    <div class="fixed inset-0 z-50 flex justify-end">
      <div class="fixed inset-0 bg-black/20" @click="$emit('close')"></div>
      <div class="w-full max-w-xl bg-base-100 shadow-2xl border-l border-base-300 relative z-10 flex flex-col" style="max-height: calc(100vh - 2rem); margin: 1rem 1rem 1rem 0; border-radius: 1rem 0 0 1rem;">
        <!-- Sticky header -->
        <div class="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-base-200">
          <h2 class="text-base font-bold truncate mr-4">{{ cert['Common Name (CN)'] }}</h2>
          <button class="btn btn-ghost btn-xs btn-circle flex-shrink-0" @click="$emit('close')">
            <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        <!-- Scrollable body -->
        <div class="flex-1 overflow-y-auto p-5 space-y-4">
          <!-- Status strip -->
          <div class="flex items-center gap-2 flex-wrap">
            <span :class="['badge badge-sm font-semibold', badge(cert.Status)]">{{ cert.Status }}</span>
            <span class="text-[11px] text-base-content/30">·</span>
            <span class="text-[11px] text-base-content/40">{{ cert['Pool Location'] }}</span>
            <span class="text-[11px] text-base-content/30">·</span>
            <span class="text-[11px] text-base-content/40">{{ cert['Issuer CA'] }}</span>
          </div>

          <!-- 2-column layout -->
          <div class="grid grid-cols-2 gap-x-5 gap-y-3">
            <!-- LEFT: Identification + Lifecycle -->
            <div class="space-y-3">
              <div>
                <h3 class="text-[10px] font-semibold uppercase tracking-widest text-base-content/30 mb-1.5 pb-1 border-b border-base-200">Identification</h3>
                <div class="space-y-1.5">
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">CN</span><p class="text-xs font-mono bg-base-200 rounded-md px-2 py-0.5 truncate">{{ cert['Common Name (CN)'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Serial</span><p class="text-xs font-mono bg-base-200 rounded-md px-2 py-0.5 truncate">{{ cert['Serial Number'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">NAR ID</span><p class="text-xs font-mono bg-base-200 rounded-md px-2 py-0.5">{{ cert['NAR ID'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Issuer</span><p class="text-xs">{{ cert['Issuer CA'] || '—' }}</p></div>
                </div>
              </div>
              <div>
                <h3 class="text-[10px] font-semibold uppercase tracking-widest text-base-content/30 mb-1.5 pb-1 border-b border-base-200">Lifecycle</h3>
                <div class="space-y-1.5">
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Issued</span><p class="text-xs">{{ cert['Issued Date'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Expiry</span><p class="text-xs font-semibold text-error">{{ cert['Expiry Date'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Days Left</span><p class="text-xs font-bold">{{ cert['Days Left'] || 0 }}d</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Renewal</span><p class="text-xs">{{ cert['Auto-Renewal'] || 'Disabled' }}</p></div>
                </div>
              </div>
            </div>

            <!-- RIGHT: Environment + SANs -->
            <div class="space-y-3">
              <div>
                <h3 class="text-[10px] font-semibold uppercase tracking-widest text-base-content/30 mb-1.5 pb-1 border-b border-base-200">Environment</h3>
                <div class="space-y-1.5">
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Project</span><p class="text-xs">{{ cert['Target Project'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Location</span><p class="text-xs">{{ cert['Pool Location'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Resource</span><p class="text-xs font-mono truncate">{{ cert['Target Resource'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">Type</span><p class="text-xs">{{ cert['Resource Type'] || '—' }}</p></div>
                </div>
              </div>
              <div>
                <h3 class="text-[10px] font-semibold uppercase tracking-widest text-base-content/30 mb-1.5 pb-1 border-b border-base-200">SANs</h3>
                <div class="space-y-1.5">
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">DNS</span><p class="text-xs font-mono truncate">{{ cert['Common Name (CN)'] || '—' }}</p></div>
                  <div><span class="text-[10px] font-semibold uppercase text-base-content/40">IP</span><p class="text-xs font-mono">{{ cert['SAN IP'] || '—' }}</p></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Sticky footer with downloads -->
        <div class="flex-shrink-0 px-5 py-3 border-t border-base-200 space-y-2">
          <button class="btn btn-primary btn-sm w-full" @click="downloadPEM(cert.PEM, cert['Common Name (CN)'] + '.pem')">
            <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            Download PEM
          </button>
          <button v-if="cert['PEM Chain'] && cert['PEM Chain'].length" class="btn btn-outline btn-sm w-full" @click="downloadPEM(cert['PEM Chain'].join('\n'), cert['Common Name (CN)'] + '-chain.pem')">
            <svg class="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            Download PEM Chain
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
defineProps({ cert: Object })
defineEmits(['close'])

function badge(s) {
  const st = String(s).toLowerCase()
  if (st === 'valid' || st === 'issued' || st === 'active') return 'badge-success'
  if (st === 'expiring') return 'badge-warning'
  return 'badge-error'
}

function downloadPEM(content, filename) {
  if (!content) return
  const blob = new Blob([content], { type: 'application/x-pem-file' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
</script>
