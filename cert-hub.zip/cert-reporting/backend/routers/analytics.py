"""Analytics routes — chart data by tab."""
import json
from fastapi import APIRouter
from backend.database import get_cached, search_certificates
from backend.charts import build_all

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

TAB_KEYS = {
    0: ["radar", "health_donut", "pool_risk"],
    1: ["by_type", "by_project", "by_location"],
    2: ["issuance_trend", "lifetime_dist"],
    3: ["key_alg", "geo_donut", "managed_by"],
    4: ["rt_status", "pj_status"],
}


@router.get("/{tab_id}")
async def analytics_tab(tab_id: int):
    df = get_cached()
    if df is None:
        df = search_certificates("NAR ID", "", ["prod-pool"], True)

    all_charts = build_all(df)
    full = json.loads(all_charts["tab0"])
    keys = TAB_KEYS.get(tab_id, [])
    tab_charts = json.dumps({k: full[k] for k in keys if k in full})

    return {
        "tab_id": tab_id,
        "tab_charts": tab_charts,
        "n24": int(len(df[df["Days Left"] == 0])),
        "n7": int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 7)])),
        "n30": int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 30)])),
        "pct_24h": min(int(len(df[df["Days Left"] == 0])) * 10, 100),
        "pct_7d": min(int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 7)])) * 5, 100),
        "pct_30d": min(int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 30)])) * 2, 100),
    }
