"""Inventory routes — search, filter, pagination, cert detail."""
import pandas as pd
from fastapi import APIRouter, Form, Query
from fastapi.responses import JSONResponse, PlainTextResponse
from backend.config import DISPLAY_COLUMNS, PAGE_SIZE
from backend.database import search_certificates, get_cached, set_cached
from backend.charts import build_all

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


def _paginate(df: pd.DataFrame, page: int) -> tuple[pd.DataFrame, int, int]:
    total_pages = max(1, (len(df) + PAGE_SIZE - 1) // PAGE_SIZE)
    page = max(1, min(page, total_pages))
    start = (page - 1) * PAGE_SIZE
    return df.iloc[start:start + PAGE_SIZE], page, total_pages


def _respond(df: pd.DataFrame, page: int = 1) -> dict:
    page_df, page_num, total_pages = _paginate(df, page)
    return {
        "count": len(df),
        "columns": DISPLAY_COLUMNS,
        "rows": page_df[DISPLAY_COLUMNS].fillna("").to_dict(orient="records"),
        "statuses": sorted(df["Status"].unique().tolist()),
        "resource_types": sorted(df["Resource Type"].dropna().unique().tolist()),
        "locations": sorted(df["Pool Location"].dropna().unique().tolist()),
        "issuers": sorted(df["Issuer CA"].dropna().unique().tolist()),
        "page": page_num,
        "total_pages": total_pages,
        "n24": int(len(df[df["Days Left"] == 0])),
        "n7": int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 7)])),
        "n30": int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 30)])),
        "pct_24h": min(int(len(df[df["Days Left"] == 0])) * 10, 100),
        "pct_7d": min(int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 7)])) * 5, 100),
        "pct_30d": min(int(len(df[(df["Days Left"] >= 0) & (df["Days Left"] <= 30)])) * 2, 100),
        "charts": build_all(df),
    }


@router.post("/search/")
async def search(
    search_type: str = Form("NAR ID"),
    search_value: str = Form(""),
    active_only: str = Form("true"),
    pools: list[str] = Form(default=["prod-pool"]),
):
    try:
        df = search_certificates(search_type, search_value, pools, active_only == "true")
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

    if df.empty:
        return JSONResponse({"error": "No records found"}, status_code=404)

    set_cached(df)
    return _respond(df)


@router.get("/filter/")
async def filter_results(
    search_value: str = "",
    search_type: str = "",
    page: int = 1,
    status: str = "",
    resource_type: str = "",
    location: str = "",
    issuer: str = "",
):
    df = get_cached()
    if df is None:
        df = search_certificates("NAR ID", "", ["prod-pool"], True)

    for param, col in [
        ("status", "Status"), ("resource_type", "Resource Type"),
        ("location", "Pool Location"), ("issuer", "Issuer CA"),
    ]:
        vals = [s.strip() for s in locals().get(param, "").split(",") if s.strip()]
        if vals:
            df = df[df[col].isin(vals)]

    return _respond(df, page)


@router.get("/cert/{idx}")
async def cert_detail(idx: int):
    df = get_cached()
    if df is None:
        return JSONResponse({"error": "No data — run a search first"}, status_code=404)
    if idx >= len(df):
        return JSONResponse({"error": "Certificate not found"}, status_code=404)
    return df.iloc[idx].fillna("").to_dict()


@router.get("/cert/{idx}/download", response_class=PlainTextResponse)
async def cert_download(idx: int):
    df = get_cached()
    if df is None or idx >= len(df):
        return "Not found"
    return df.iloc[idx].get("PEM", "No PEM available")
